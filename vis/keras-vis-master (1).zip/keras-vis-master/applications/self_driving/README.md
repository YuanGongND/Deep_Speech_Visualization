# Credits

Pre-trained model and code borrowed from https://github.com/experiencor/self-driving-toy-car. Here is the model in
action.
<a href="https://www.youtube.com/watch?v=-v6q2dNZTU8" rel="some text"><p align="center">![Foo](https://i.imgflip.com/1rking.gif)</p></a>
