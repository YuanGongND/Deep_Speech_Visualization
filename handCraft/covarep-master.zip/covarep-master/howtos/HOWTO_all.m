% A helper function to check that all HOWTOs are working

HOWTO_spectra;
HOWTO_features;
HOWTO_sinusoidal;
HOWTO_egg;
HOWTO_glottalsource;
HOWTO_VAD;
HOWTO_envelope;
HOWTO_formant;
HOWTO_hmpd;
