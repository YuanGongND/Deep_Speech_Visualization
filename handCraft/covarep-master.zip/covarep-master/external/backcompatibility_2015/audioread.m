function [y,Fs] = audioread(filename)

    [y,Fs] = wavread(filename);

return
